package com.example.updata.Model;

import android.content.Context;
import android.util.Log;

import java.io.File;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;

import static android.support.constraint.Constraints.TAG;

public class Text {
    public void upload(Context file){
        Log.e(TAG, "upload: " );
        OkHttpClient client = new OkHttpClient();
        File outputImage = new File(file.getExternalCacheDir(), "output_image.jpg");
        Log.e(TAG, "uploadImage: " );

        RequestBody fileBody = RequestBody.create(MediaType.parse("image/png"), outputImage);
        RequestBody requestBody = new MultipartBody.Builder()
                .setType(MultipartBody.FORM)
                .addFormDataPart("file", "testImage.jpg", fileBody)
                .build();
        Request request = new Request.Builder()
                .url("http://localhost:8080/HelloServlet")
                .post(requestBody)
                .build();
    }
}

package com.example.updata.Model;

import android.app.Activity;

public interface I_CreateP<T> {
    public void getImage(Activity context, int i);
}

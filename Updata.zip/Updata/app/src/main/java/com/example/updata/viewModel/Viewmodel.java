package com.example.updata.viewModel;

import android.app.Activity;
import android.content.Context;
import android.database.Cursor;
import android.databinding.BaseObservable;
import android.databinding.ObservableField;
import android.net.Uri;
import android.provider.MediaStore;
import android.util.Log;
import com.example.updata.ButtomDilog;
import com.example.updata.Model.Text;

import java.io.File;



public class Viewmodel extends BaseObservable {
    private Activity context;
    public String button = "点击上传头像";
    public ObservableField<Object> image = new ObservableField<>();
    public File file;


    public Viewmodel(Activity context) {
        this.context = context;
        image.set("https://ss1.bdstatic.com/70cFuXSh_Q1YnxGkpoWK1HF6hhy/it/u=3300305952,1328708913&fm=27&gp=0.jpg");
    }

    public void log() {
        Log.d("MyViewModel", "点击按钮");
        ButtomDilog dilog = new ButtomDilog(context);
        dilog.show();
    }

    public void update() {
        Text text = new Text();
        text.upload(context);
    }

    public void setUrl(Object url) {
        if (url instanceof Uri) {
            file = new File(getRealPathFromURI(context, (Uri) url));
        } else {
            file = (File) url;
        }
        image.set(url);
    }

    public String getRealPathFromURI(Context context, Uri contentURI) {
        String result;
        Cursor cursor = context.getContentResolver().query(contentURI,
                new String[]{MediaStore.Images.ImageColumns.DATA},
                null, null, null);
        if (cursor == null) {
            result = contentURI.getPath();
        } else {
            cursor.moveToFirst();
            int index = cursor.getColumnIndex(MediaStore.Images.ImageColumns.DATA);
            result = cursor.getString(index);
            cursor.close();
        }
        return result;
    }
}

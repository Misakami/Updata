package com.example.updata.Model;

import android.content.Context;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

public class Const {
    public static int Take_Photo = 1;
    public static int Chose_Image = 2;
}
